# GAME_BAMBOO

1~10 Wave
fun 2000's flash game
